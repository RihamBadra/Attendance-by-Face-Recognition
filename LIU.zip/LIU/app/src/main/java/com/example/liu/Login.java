package com.example.liu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.opencv.com.example.liu.R;

//import com.google.android.gms.tasks.OnCompleteListener;
//import com.google.android.gms.tasks.Task;
//import com.google.firebase.auth.AuthResult;
//import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    private EditText emails;
    private EditText password;
    private Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emails =(EditText)findViewById(R.id.email);
        password=(EditText)findViewById(R.id.password);
        login=findViewById(R.id.btn_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = emails.getText().toString();
                String pass = password.getText().toString();

                if (TextUtils.isEmpty((CharSequence) email)) {
                    emails.setError("Email is Required");
                }
                if (TextUtils.isEmpty(pass)) {
                    password.setError("Password is Required");
                }

                //check the user
                if (email == "ali.bazzi@liu.edu.lb" && pass == "ali123"){
                    Toast.makeText(Login.this, "Welcome dr. Ali Bazzi", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), campus.class));
                } else {
                    Toast.makeText(Login.this, "Please enter a valid username and password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

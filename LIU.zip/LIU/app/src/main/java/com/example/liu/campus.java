package com.example.liu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import org.opencv.com.example.liu.R;

public class campus extends AppCompatActivity {

    private Button nex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campus);

        //1st spinner

        //create the first spinner with defined items on strings.xml
        Spinner sp1= findViewById(R.id.spinner);
        //create its own adapter (for the array made)
        ArrayAdapter<CharSequence> ad1= ArrayAdapter.createFromResource(this, R.array.camp, android.R.layout.simple_list_item_1);
        //set the adapter to the spinner
        sp1.setAdapter(ad1);


        //2nd spinner

        //create the first spinner with defined items on strings.xml
        Spinner sp2= findViewById(R.id.spinner2);
        //create its own adapter (for the array made)
        ArrayAdapter<CharSequence> ad2= ArrayAdapter.createFromResource(this, R.array.sec, android.R.layout.simple_list_item_1);
        //set the adapter to the spinner
        sp2.setAdapter(ad2);



        nex=findViewById(R.id.btn);
        nex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }
}
